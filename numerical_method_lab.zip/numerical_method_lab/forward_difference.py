# -*- coding: utf-8 -*-
"""
Created on Wed Jul  7 20:48:36 2021

@author: User
"""
import numpy as np
def fx(x):
    return ((2000*np.log(140000/(140000-2100*x)))-9.8*x)
def differential_fx(x):
    return (2000*2100/(140000-2100*x)-9.8)

def jerk_by_diff(x):
    return (2000*2100**2/(140000-2100*x)**2)

def diff_by_forwrd(x,dx):
    return (fx(x+dx)-fx(x))/dx

def diff_by_backwrd(x,dx):
    return (fx(x)-fx(x-dx))/dx
def diff_by_centrl(x,dx):
    
    return ((fx(18)-fx(14))/(2*dx))
def jerk_by_frwrd(x,dx):
    return((fx(x+dx)-2*fx(x)+fx(x-dx))/dx**2)

def main():
    a1=diff_by_forwrd(16,2)
    a2=differential_fx(16)
    a3=diff_by_backwrd(16, 2)
    a_c=diff_by_centrl(16, 2)
    jrk=jerk_by_frwrd(16, .5)
    jrk_d=jerk_by_diff(16)
    print(a1,a2,a3,a_c,jrk,jrk_d)
    error1=abs(a1-a2)/a2*100
    error2=abs(a3-a2)/a2*100
    error3=abs(a_c-a2)/a2*100
    error_j=abs(jrk-jrk_d)/jrk_d*100
    print(error1,error2,error3,error_j)
    
    
main()