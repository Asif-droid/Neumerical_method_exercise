# -*- coding: utf-8 -*-
"""
Created on Sat Mar 13 22:35:01 2021

@author: User
"""


import numpy as np
import matplotlib.pyplot as plt
from tabulate import tabulate
from math import sqrt


table=[]


pi=3.1416
def f(h):
    #return ((x/(1-x)*sqrt(2*3/(2+x)))-.05)
    #return (x**3-(x**2)*(6/(.05**2))-3*x+2)
    return ((pi*(h**3))-(9*pi*(h**2))+12)
   

def bisection(a,b,err,max_it):
    xl=a
    xr=b
    i=0
    prev_c=(xl+xr)/2
    while(i<=max_it):
        c=(xl+xr)/2
        if(i!=0):
            c_err=abs((c-prev_c)*100/c)
            table.append([i+1,c,c_err])
            if(c_err<=err):
                
                return c
        else:
            table.append([i+1,c,"__"])
        prod=f(xl)*f(c)
        if(prod<0):
            xr=c
        else:
            xl=c
        i+=1
        prev_c=c
    return c
def draw():
    f2=np.vectorize(f)
    x=np.linspace(0,2,100)
    plt.plot(x,f2(x))
    plt.grid()
    plt.show()


print(bisection(8,0, .5,20))
print(tabulate(table,headers=["Iterations","Root","Error%"]))
#draw()
