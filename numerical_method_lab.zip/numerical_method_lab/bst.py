# -*- coding: utf-8 -*-
"""
Created on Sun Feb 28 21:53:12 2021

@author: User
"""


class node:
    def __init__(self,data=None):
        self.data=data
        self.right_node=None
        self.left_node=None
        
class bst:
    def __init(self):
        self.root=None
        self.key_node=None