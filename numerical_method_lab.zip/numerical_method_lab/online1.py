# -*- coding: utf-8 -*-
"""
Created on Sat May 29 11:10:07 2021

@author: User
"""

import numpy as np
import matplotlib.pyplot as plt
from tabulate import tabulate

pi=3.1416
table=[]
def fx(h):
    #return ((pi*(h**3))-(9*pi*(h**2))+12)
    return (pi*(h**2)*(9-h))-12


def bisection(a,b,err,max_it):
    xl=a
    xr=b
    i=0
    prev_c=(xl+xr)/2
    while(i<=max_it):
        c=(xl+xr)/2
        if(i!=0):
            c_err=abs((c-prev_c)*100/c)
            table.append([i+1,c,c_err])
            if(c_err<=err):
                
                return c
        else:
            table.append([i+1,c,"__"])
        prod=fx(xl)*fx(c)
        if(prod<0):
            xr=c
        else:
            xl=c
        i+=1
        prev_c=c
    return c



print(bisection(8, 0, .05, 20))
print(tabulate(table,headers=["iterations","value","error"]))
