# -*- coding: utf-8 -*-
"""
Created on Sat May 29 07:55:32 2021

@author: User
"""
import numpy as np

mat1=[[1.0,1.0,1.0],[-1,-2,1],[-1,1,-5]]
mat2=[[0],[-1],[2]]
x=3
solution=True

def Gaussian(mat1,mat2):
    print (mat1)
    mat=np.append(mat1,mat2,axis=1)
    for i in range(0,x-1,1):
        for j in range(i+1,x,1):
            coff=mat[j][i]/mat[i][i]*-1
            mat[j]=np.add(mat[j],coff*mat[i])
        print(mat)
        
    for i in range(0,x,1):
        matrix=np.matrix(mat[i])
        m=matrix.sum(axis=1,dtype='float')
        if(m==mat[i][x]):
            if(mat[i][x]==0):
                solution=False
                print("Infinite solution")
            else:
                
                solution=False
                print("no solution")
            break
            
        
    #print()
    root=np.zeros((x,1),float)
    s=0
    for i in range(x-1,-1,-1):
        for j in range(i+1,x,1):
            s+=mat[i][j]*root[j]
        
        root[i]=(mat[i][x]-s)/mat[i][i]
        s=0
    if(solution):
        print(root)
    
    
Gaussian(mat1, mat2)
print(mat1)