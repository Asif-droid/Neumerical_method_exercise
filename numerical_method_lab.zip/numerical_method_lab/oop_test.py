# -*- coding: utf-8 -*-
"""
Created on Sat Feb 27 23:55:07 2021

@author: User
"""


class node:
    def __init__(self,dataval=None):
        self.dataval=dataval
        self.nextval=None
        self.prevval=None

class linked_list:
    def __init__(self):
        self.head=None
        self.keyval=None
    def list_print_fromEnd(self):
        printval=self.keyval
        while printval is not None:
            print(printval.dataval)
            printval=printval.prevval
    def push(self,data=None):
        if(self.head is None):
            head_element=node(data)
            self.keyval=head_element
            self.head=self.keyval
        else:
            old_key=self.keyval
            element=node(data)
            element.prevval=old_key
            old_key.nextval=element
            self.keyval=element
        
    def print_from_strt(self):
        printval=self.head
        while printval is not None:
            print(printval.dataval)
            printval=printval.nextval
        
        
        
def test():
    list1=linked_list()
    list1.push("mon")
    list1.push("sun")
    list1.push("fri")
    list1.list_print_fromEnd()
    print("Break")
    list1.print_from_strt()
test()






