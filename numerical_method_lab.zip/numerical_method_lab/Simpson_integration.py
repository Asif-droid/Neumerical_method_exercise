# -*- coding: utf-8 -*-
"""
Created on Thu Jun 17 21:55:13 2021

@author: User
"""

import numpy as np
from tabulate import tabulate
def fx(x):
    return ((2000*np.log(140000/(140000-2100*x)))-9.8*x)

def integration(n,a,b):
    iteration=2*n
    h=(float)(b-a)/iteration
    s=0
    for i in range(1,iteration,2):
       s=s+(fx(a+(i-1)*h)+4*fx(a+(i*h))+fx(a+(i+1)*h))
       
    return (h*s)/3

def main():
    value=integration(7,8,30)
    table=[]
    print(value)
    old_v=0
    for i in range(1,6,1):
        v=integration(i, 8, 30)
        if(i>1):
            err=abs(old_v-v)/v*100
            table.append([i,v,err])
        else:
            table.append([i,v,"--"])
        old_v=v
    print(tabulate(table,headers=["iteration","value","error"]))   
    
    
       
       

print(fx(20))
print(2*fx(22.5))
print(fx(30
         ))
     
       
       
       
       
       
       
       
       
       
       
       
       