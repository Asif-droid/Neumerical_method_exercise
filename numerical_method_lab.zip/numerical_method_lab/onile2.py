# -*- coding: utf-8 -*-
"""
Created on Sat Jun  5 11:12:03 2021

@author: User
"""


import numpy as np

tminput=[0,5,9,12,19,22,26,28,30,33,40]
massinput=[1011,1255,1347,1101,1203,1245,1378,1315,1475,1547,1689]
n=len(massinput)
D=np.zeros((n,n),dtype='float')
D[:,0]=massinput

tfind=25   #value to find
for j in  range(1,n,1):
    for i in range(j,n,1):
        D[i][j]=(D[i][j-1]-D[i-1][j-1])/(tminput[i]-tminput[i-j])


s=0
for i in range(0,n,1):
    p=1
    for j in range(0,i,1):
        p*=(tfind-tminput[j])
        
    s=s+D[i][i]*p
print(s)


#for vel

tvinput=[0,5,9,12,19,22,26,28,30,33,40]
velinput=[100,1500,2000,2500,3000,3500,4000,4500,5000,5500,6000]
n1=len(velinput)
D1=np.zeros((n1,n1),dtype='float')
D1[:,0]=velinput
tvfind= 25  #value to find
for j in  range(1,n1,1):
    for i in range(j,n1,1):
        D1[i][j]=(D1[i][j-1]-D1[i-1][j-1])/(tvinput[i]-tvinput[i-j])


s1=0
for i in range(0,n,1):
    p1=1
    for j in range(0,i,1):
        p1*=(tvfind-tvinput[j])
        
    s1=s1+D1[i][i]*p1
print(s1)
  