# -*- coding: utf-8 -*-
"""
Created on Thu May 27 23:57:15 2021

@author: User
"""


import numpy as np
import matplotlib.pyplot as plt
from tabulate import tabulate

table =[]
def fx(x):
    return ((x**3)-.165*(x**2)+(3.993*(10**(-4))))
def f1x(x):
    return (3*(x**2)-(.165*2*x))


def newt_raph(x,err,mx_iter):
    er=5
    i=0;
    while(i<mx_iter):
        x2=x-(fx(x)/f1x(x))
        er=(x2-x)/x2
        table.append([i,x2,abs(er)])
        if(abs(er)<err):
            return x2
        x=x2
        i+=1
    return x
    
def draw():
    f2=np.vectorize(fx)
    x=np.linspace(-1,1,50)
    plt.plot(x,f2(x))
    plt.grid()
    plt.show()        
print (newt_raph(.05, .05,3))
print(tabulate(table,headers=["iterations","root","error"]))
draw()