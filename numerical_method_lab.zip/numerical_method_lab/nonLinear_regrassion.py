# -*- coding: utf-8 -*-
"""
Created on Fri Jul  2 21:51:16 2021

@author: User
"""

import matplotlib.pyplot as plt
import numpy as np

time=[ 0,
1,
3,
5,
7,
9
]

gama=[ 1.000,
0.891,
0.708,
0.562,
0.447,
0.355
]
def exp(x):
    return np.exp(x)

def flmbda(lmbda,n):
    s1=0
    s2=0
    s3=0
    s4=0
    for i in range(0,n,1):
        s1+=gama[i]*time[i]*exp(lmbda*time[i])
        s2+=gama[i]*exp(lmbda*time[i])
        s3+=exp(2*lmbda*time[i])
        s4+=time[i]*exp(2*lmbda*time[i])
        
    return s1-(s2*s4/s3)
    

    
def draw():
    plt.plot(time, flmbda(time, len(time)) )
    plt.show()

draw()

















