# -*- coding: utf-8 -*-
"""
Created on Wed Mar 31 14:10:21 2021

@author: User
"""
import numpy as np


x=int(input("Enter every row in one line with space between each coeffecient\n"))
l=list()
for i in range(0,x,1):
    a=list(map(float,input().split(' ')))
    l.append(a)
mat1=np.array(l)
l=list()
print("now enter 2nd matrix(column mat)")
for i in range(0,x,1):
    a=float(input())
    l.append(a)
res=np.array([[i]for i in l])


def GaussianElimination(a,b,d):
    mat=np.array(a)
    mat=np.append(mat,b,axis=1)
    print(mat)
    for i in range(0,x-1,1):
        for j in range(i+1,x,1):
            cof=mat[j][i]/mat[i][i]*-1
            mat[j]=np.add(mat[j],cof*mat[i])
        if(d):
            print(mat)
    root=np.zeros((x,1),float)
    s=0
    for i in range(x-1,-1,-1):
        for j in range(i+1,x,1):
            s+=mat[i][j]*root[j]
            #print(s)
        root[i]=(mat[i][x]-s)/mat[i][i]
        s=0
    print("root")
    print(root)
GaussianElimination(mat1, res,d=True)










