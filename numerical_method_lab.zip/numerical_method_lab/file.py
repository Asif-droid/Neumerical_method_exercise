# -*- coding: utf-8 -*-
"""
Created on Sat Mar 13 11:25:01 2021

@author: User
"""
def writeFile(filename, lines):
    fo=open(filename,'w')
    fo.write(lines)
    

def readFile(filename):
    try:
        fo=open(filename,'r')
        st=fo.readlines();
        print(st)
        fo.close()
    except:
        print("file not found")
    
    
    
readFile('asif.txt')