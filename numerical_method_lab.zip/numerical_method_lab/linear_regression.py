# -*- coding: utf-8 -*-
"""
Created on Fri Jul  2 21:11:43 2021

@author: User
"""

import matplotlib.pyplot as plt
import numpy as np

theta=[ 0.698132,       #x
0.959931,
1.134464,
1.570796,
1.919862
]
T=[ 0.188224,       #y
0.209138,
0.230052,
0.250965,
0.313707
]



def findA1(n):
    theta_sqr=[]
    for i in range(0,n,1):
        theta_sqr.append(theta[i]**2)
    
    s1=0
    s2=0
    s3=0
    s4=0
    for i in range(0,n,1):
        s1+=theta[i]*T[i]
        s2+=theta[i]
        s3+=T[i]
        s4+=theta_sqr[i]
    return (n*s1-s2*s3)/(n*s4-s2**2)
        
        
    
def findA0(a1,n):
    s_x=0
    s_y=0
    for i in range(0,n,1):
        s_x+=theta[i]
        s_y+=T[i]
    return (s_y/n)-(a1*s_x/n)

def fx(a0,a1,x):
    return a0+a1*x

def drawLie(n,a0,a1):
    y=[]
    for i in range(0,n,1):
        y.append(fx(a0,a1,theta[i]))
        
    plt.plot(theta,y)
    plt.scatter(theta, T)
    plt.show()
    
def drawpoints():
    plt.scatter(theta, T)
    plt.show()
    

def main():
    a1=findA1(len(theta))
    a0=findA0(a1, len(theta))
    print(a0,"+",(a1),"theta")
    #drawpoints()
    drawLie(len(theta),a0, a1)
main()
    
    
    
    
    
    
    
    
    
    
    
    