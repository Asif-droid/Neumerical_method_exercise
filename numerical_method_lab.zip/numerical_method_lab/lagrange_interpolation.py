# -*- coding: utf-8 -*-
"""
Created on Wed Jun  2 11:13:39 2021

@author: User
"""

 
xinput=[0,1,5,9,10,12]
yinput=[0,1,5,9,10,12]
table=[]
n=len(xinput)

def lagrange_fx(x,n):
    s=0
    for i in range (0,n,1):
       p=1
       for j in range (0,n,1):
           if(j!=i):
               p=p*(x-xinput[j])/(xinput[i]-xinput[j])
       
       s=s+p*yinput[i]
       
    return s

print(lagrange_fx(7, n))
