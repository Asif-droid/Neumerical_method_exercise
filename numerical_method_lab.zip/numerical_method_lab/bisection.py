# -*- coding: utf-8 -*-
"""
Created on Fri May 28 10:51:06 2021

@author: User
"""


import numpy as np
import matplotlib.pyplot as plt
from tabulate import tabulate
pi=3.1416
def fx(h):
    #return ((x**3)-.165*(x**2)+3.99*(10**(-4)))
    return ((pi*(h**3))-(9*pi*(h**2))+12)
table=[]
def bisection(xl,xs,err,mx_itr):
    i=0
    prev_c=0
    while(i<mx_itr):
        c=(xl+xs)/2
        if(i!=0):
            er=abs((c-prev_c)/c)
            table.append([i,c,er])
            if(er<err):
                return c
        prod=fx(c)*fx(xl)
        if(prod<0):
            xs=c
        else:
            xl=c
        
        i+=1
        prev_c=c
        #print(prev_c,"from ")
    
    return prev_c
    
print(bisection(0, 8, .05, 20)) 
print(tabulate(table,headers=["iterate","root","err"]))      