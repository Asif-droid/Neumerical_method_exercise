# -*- coding: utf-8 -*-
"""
Created on Sat Jul  3 12:32:40 2021

@author: User
"""

import matplotlib.pyplot as plt
import numpy as np

x=[]
y=[]
z=[]    
def read():
    my_file = open("data.txt", "r")
    content = my_file.readlines()
    c=0
    for i in content:
        
        
        i=i.strip("\n")
        ls=i.split(" ")
        
        x.append(float(ls[0]))
        y.append(float(ls[1]))
       # print(x,y)
        c+=1      
    

def createMat(n,o,x,y,z):
    a=np.zeros((o,o))
    b=np.zeros((o))
    print(z)
    s1=0
    s2=0
    s3=0
    s4=0
    s5=0
    for i in range(0,n,1):
        s1+=x[i]**2
        s2+=x[i]*z[i]
        s3+=z[i]**2
        s4+=x[i]*y[i]
        s5+=y[i]*z[i]
    a[0][0]=s1
    a[0][1]=s2
    a[1][0]=s2
    a[1][1]=s3
    b[0]=s4
    b[1]=s5
            
    return a,b



def Gaussian(mat1,mat2,x):
    solution=True
    mat=np.append(mat1, mat2,axis=1)
    for i in range(0,x-1,1):
        for j in range(i+1,x,1):
            coff=mat[j][i]/mat[i][i]*-1
            mat[j]=np.add(mat[j],coff*mat[i])
        print(mat)
        
    for i in range(0,x,1):
        matrix=np.matrix(mat[i])
        m=matrix.sum(axis=1,dtype='float')
        if(m==mat[i][x]):
            if(mat[i][x]==0):
                solution=False
                print("Infinite solution")
            else:
                
                solution=False
                print("no solution")
            break
            
        
    #print()
    root=np.zeros((x,1),float)
    s=0
    for i in range(x-1,-1,-1):
        for j in range(i+1,x,1):
            s+=mat[i][j]*root[j]
        
        root[i]=(mat[i][x]-s)/mat[i][i]
        s=0
    if(solution):
        print(root)
    return root
def fx(a,b,x,z):
    return a*x+b*z 
def drawLie(n,a,b,x,z,y):
    y1=[]
    for i in range(0,n,1):
        y1.append(fx(a,b,x[i],z[i]))
        
    plt.plot(x,y1)
    plt.scatter(x,y)
    plt.show()       
def main():
    read()
    z=np.exp(x)
    
    mat1,mat2=createMat(len(x), 2,x,y,z)
    mat2=mat2.reshape(2,1)
    ans=Gaussian(mat1, mat2, 2)
    drawLie(len(x),ans[0],ans[1],x,z,y)
    
    
    
main()
        

        
        
        
        
        