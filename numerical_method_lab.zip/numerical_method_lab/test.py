# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""
a=[[1,2,3],[4,5,6],[7,8,9]]
b=[[1,2,3],[4,5,6],[7,8,9]]

c=list()
for i in range(0,3,1):
    item=list()
    for j in range(0,3,1):
       item.append (a[i][j]+b[i][j]) 
    c.append(item)
print(c)