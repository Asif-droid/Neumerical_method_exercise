# -*- coding: utf-8 -*-
"""
Created on Fri Jun  4 06:42:06 2021

@author: User
"""

import numpy as np
import  matplotlib.pyplot as plt
tvinput=[0,5,9,12,19,22,26,28,30,33,40]
velinput=[100,1500,2000,2500,3000,3500,4000,4500,5000,5500,6000]
tminput=[0,5,9,12,19,22,26,28,30,33,40]
massinput=[1011,1255,1347,1101,1203,1245,1378,1315,1475,1547,1689]

from tabulate import tabulate
xfind=25   #value to find
tablem=[]

def newt(xinput,yinput,n,xfind):
    D=np.zeros((len(yinput),len(yinput)),dtype='float')
    D[:,0]=yinput
    for j in  range(1,n,1):
        for i in range(j,n,1):
            D[i][j]=(D[i][j-1]-D[i-1][j-1])/(xinput[i]-xinput[i-j])
    
    
    s=0
    for i in range(0,n,1):
        p=1
        for j in range(0,i,1):
            p*=(xfind-xinput[j])
            
        s=s+D[i][i]*p
    #print(s)
    return s

mass=newt(tminput[4:7],massinput[4:7],len(massinput[4:7]),xfind)
vel=newt(tminput,velinput,len(velinput),xfind)    
print(mass)
print(vel)

def error(value,xinput,yinput):
    for i in range(2,10,2):
        m=int(i/2)
        tempx=xinput[7-m:7+m:1]
        tempy=yinput[7-m:7+m:1]
        v=newt(tempx, tempy,len(tempy), 25)
        err=abs(v-value)/v*100
        tablem.append([i,err])
        
    
def draw(xinput,yinput,n):
    x=np.linspace(0,40,40)
    
    plt.plot(x,newt(xinput, yinput, n, x))
    plt.grid()
    plt.show()
    
draw(tminput,massinput,len(massinput))
draw(tminput,velinput,len(velinput))
error(vel,tminput,velinput)
print(tabulate(tablem))


#differenciate
from sympy import *
import Interpolate


x = Symbol('x')
mx,my,mn = Interpolate.findTable([[19, 1203], [22, 1245], [26, 1378], [28, 1315], [30, 1475]])
vx,vy,vn = Interpolate.findTable([[19,3000],[22,3500],[26,4000],[28,4500],[30,5000]])
f = Interpolate.findValue(x,mx,my,mn)*Interpolate.findValue(x,vx,vy,vn)
f_prime = f.diff(x)
print(f)
print(f_prime)
f_prime = lambdify(x, f_prime)
print("Force at 25s is: ", f_prime(25))







