# -*- coding: utf-8 -*-
"""
Created on Sat Jul  3 09:32:32 2021

@author: User
"""
import matplotlib.pyplot as plt
import numpy as np
import math

x=[]
y=[]
z=[]
ans=[]
def fx(q):
    return ans[0]*.005+ans[1]*1.9*q+ans[2]*np.exp(q*1.5)
def exp(n):
    return np.power(n)
def read():
    my_file = open("data.txt", "r")
    content = my_file.readlines()
    c=0
    for i in content:
        
        
        i=i.strip("\n")
        ls=i.split(" ")
        
        x.append(float(ls[0]))
        y.append(float(ls[1]))
       # print(x,y)
        c+=1
    

def createMat(n,o):
    a=np.zeros((o+1,o+1))
    b=np.zeros((o+1))
    for i in range(1,o+2,1):
        for j in range(1,i+1,1):
            k=i+j-2
            s=0
            for l in range(0,n,1):
                s+=x[l]**k
            a[i-1][j-1]=s
            a[j-1][i-1]=s
        s_b=0
        for l in range(0,n,1):
            s_b+=y[l]*x[l]**(i-1)
        b[i-1]=s_b
    return a,b



def Gaussian(mat1,mat2,x):
    solution=True
    mat=np.append(mat1, mat2,axis=1)
    for i in range(0,x-1,1):
        for j in range(i+1,x,1):
            coff=mat[j][i]/mat[i][i]*-1
            mat[j]=np.add(mat[j],coff*mat[i])
        print(mat)
        
    for i in range(0,x,1):
        matrix=np.matrix(mat[i])
        m=matrix.sum(axis=1,dtype='float')
        if(m==mat[i][x]):
            if(mat[i][x]==0):
                solution=False
                print("Infinite solution")
            else:
                
                solution=False
                print("no solution")
            break
            
        
    #print()
    root=np.zeros((x,1),float)
    s=0
    for i in range(x-1,-1,-1):
        for j in range(i+1,x,1):
            s+=mat[i][j]*root[j]
        
        root[i]=(mat[i][x]-s)/mat[i][i]
        s=0
    #root=root.reshape(1,3)
    for i in range(0,3):
        ans.append(root[i])
    if(solution):
        print(root)
        
        
        
        
def drawLie(n):
    y1=[]
    for i in range(0,n,1):
        y1.append(fx(x[i]))
        
    plt.plot(x,y1)
    plt.scatter(x,y)
    plt.show()
def drawpoints():
    plt.scatter(x, y)
    plt.show()
def main():
    read()
    z=np.exp(x)
    print(z)
    drawpoints()
    a,b=createMat(len(x), 2)
    nb=b.reshape(3,1)
    
    print(ans)    
    Gaussian(a, nb,3)
    drawLie(len(x))
    

main()






















