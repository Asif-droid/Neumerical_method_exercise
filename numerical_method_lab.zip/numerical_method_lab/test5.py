# -*- coding: utf-8 -*-
"""
Created on Sat Jul  3 10:03:02 2021

@author: User
"""


x=[ 
]

my_file = open("data.txt", "r")
content = my_file.readlines()
c=0
for i in content:
    
    if(c==0):
        c+=1
        continue
    i=i.strip("\n")
    ls=i.split(" ")
    x=ls[0]
    print(x)
    
    c+=1

print()